import sqlite3


def get_user(username):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()
    resp = cursor.execute('SELECT * FROM user WHERE username=?', (username, )).fetchone()
    conn.close()
    return resp


def insert_user(username, password, role, name, familia):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO user (username, password, role, name, familia) '
                   'VALUES (?, ?, ?, ?, ?)', (username, password, role, name, familia))
    conn.commit()
    conn.close()


def load_params_of_test_created_by_username(username, *params):
    '''Возвращает короткую информацию (столбцы params) о всех тестах, сделанных username'''

    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()

    resp = cursor.execute(f'SELECT {", ".join(params)} FROM test where username_of_creator=?', (username, )).fetchall()
    conn.close()

    # Преобразование [(..., ..., ...), (..., ..., ...)] в [{name: ..., description: ..., date: ...}, {...}]
    lst = []
    for i in range(len(resp)):
        lst.append({})
        for j in range(len(params)):
            lst[i][params[j]] = resp[i][j]

    return lst


def add_test_to_db(dct, username, date):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()

    cursor.execute('INSERT INTO test (username_of_creator, date_of_creation, name, description) '
                   'VALUES (?, ?, ?, ?)',
                   (username, date.strftime("%Y-%m-%d %H:%M:%S"), dct['name'], dct['description'])
    )

    id = cursor.lastrowid

    question_keys = list(dct.keys())[2:]

    for question_key in question_keys:
        question = dct[question_key]

        cursor.execute('INSERT INTO question (test_id, question, image) '
                       'VALUES (?, ?, ?)',
                       (id, question['question'], question.get('image')))

        question_id = cursor.lastrowid

        answers = question['answers']

        for answer_id in answers.keys():
            answer = answers[answer_id]

            cursor.execute('INSERT INTO answer (question_id, answer, is_correct) '
                           'VALUES (?, ?, ?)',
                           (question_id, answer['text'], answer['is_correct']))

    conn.commit()
    conn.close()


def load_param_of_test(id):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()

    resp = cursor.execute("SELECT * FROM test WHERE id=?", (id, )).fetchone()
    conn.close()

    return resp


def load_solutions(test_id):
    '''
    test_id -> [(name1+familia1, mark1, cheated1, time1), (..., ..., ..., ...), ...]
    '''