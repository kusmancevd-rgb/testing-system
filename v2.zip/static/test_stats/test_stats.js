async function loadSolutions() {
    let resp = await fetch(
        window.location.href,
        {
            method: 'POST',
            body: JSON.stringify({'type': 'load_solutions'}),
            headers: {
                'Content-Type': 'application/json'
        }
        }

    );

    resp = await resp.json();
    
    if (resp['type'] != 'success') {
        return;
    }

    let solutions = resp['solutions'];

    let result;

    if (solutions.length == 0) {
        result = 'У этого теста пока нету решений';
    } else {
        result = `<table class='table'>
                    <tr>
                        <td>Имя</td>
                        <td>Балл</td>
                        <td>Списано</td>
                        <td>Время выполнения</td>
                    </tr>`;
        
        
        for (let solution of solutions) {
            result += `<tr>
                        <td>${solution['name']}</td>
                        <td>${solution['score']}</td>
                        <td>${solution['cheated']}</td>
                        <td>${solution['time']}</td>
                    </tr>`;
        }
        
        result += '</table>';
    }

    document.querySelector('.solutions').insertAdjacentHTML('afterbegin', result);
}


loadSolutions();
