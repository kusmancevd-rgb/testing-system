from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from flask_login import LoginManager, UserMixin, login_user, login_required, current_user

from database import get_user, insert_user


app = Flask(__name__)
app.secret_key = 'ddcocog'

login_manager = LoginManager()
login_manager.init_app(app)


class User(UserMixin):
    def __init__(self, username, password, role, name, familia):
        self.username = username
        self.password = password
        self.role = role
        self.name = name
        self.familia = familia

    def get_id(self):
        return self.username


@login_manager.user_loader
def load_user(username):
    resp = get_user(username)
    if not resp:
        return None
    return User(*resp)


@app.route('/', methods=['GET', 'POST'])
def login_page():
    if request.method == 'GET':
        if not current_user.is_authenticated:
            return render_template('login.html')
        return redirect(url_for('teacher_page'))

    if request.method == 'POST':
        data = request.get_json()
        username = data['login']
        password = data['password']

        user = load_user(username)

        if not user:
            return jsonify({'type': 'IncorUsername', 'html': 'некорректный пользователь'})

        if user.password == password:
            login_user(user, remember=True)
            if user.role == 'teacher':
                return redirect(url_for('teacher_page'))
            if user.role == 'student':
                return redirect(url_for('student_page'))
        else:
            return jsonify({'type': 'IncorPassword', 'html': 'неверный пароль!'})


@app.route('/register', methods=['GET', 'POST'])
def register_page():
    if request.method == 'GET':
        if not current_user.is_authenticated:
            return render_template('register.html')
        return redirect(url_for('teacher_page'))

    if request.method == 'POST':
        data = request.get_json()
        username = data['username']
        password = data['password']
        repeatpassword = data['repearpassword']
        role = data['role']
        name = data['name']
        familia = data['familia']

        if load_user(username):
            return jsonify({'type': "IncorData", 'html': "Данный username уже занят"})
        if password != repeatpassword:
            return jsonify({'type': "IncorData", 'html': "Пароли не совпадают"})
        if not (password and username and name and familia):
            return jsonify({'type': 'IncorData', 'html': "Заполните все поля"})

        insert_user(username, password, role, name, familia)
        user = load_user(username)

        login_user(user, remember=True)

        if user.role == 'teacher':
            return redirect(url_for('teacher_page'))
        if user.role == 'student':
            return redirect(url_for('student_page'))


@app.route('/teacher')
@login_required
def teacher_page():
    if request.method == 'GET':
        return render_template('teacher.html')


@app.route('/student')
@login_required
def student_page():
    if request.method == 'GET':
        return render_template('student.html')


app.run()