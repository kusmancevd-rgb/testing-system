import sqlite3


def get_user(username):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()
    resp = cursor.execute('SELECT * FROM user WHERE username=?', (username, )).fetchone()
    conn.close()
    return resp


def insert_user(username, password, role, name, familia):
    conn = sqlite3.connect('db.sqlite3')
    cursor = conn.cursor()
    cursor.execute('INSERT INTO user (username, password, role, name, familia) '
                   'VALUES (?, ?, ?, ?, ?)', (username, password, role, name, familia))
    conn.commit()
    conn.close()