async function sendLoginData() {
    let text = await fetch('http://127.0.0.1:5000/', {
        method: "POST", 
        body: JSON.stringify({'login': document.querySelector('.login').value, 
            'password': document.querySelector('.password').value
        }),
        headers: {
        'Content-Type': 'application/json'
        }, 
    }
    );

    if (text.redirected) {  // верные данные
        window.location.href = text.url;
        return;
    }

    text = await text.json();

    let type = text['type'];

    if (type == 'IncorUsername' || type == 'IncorPassword') {
        let prev_error = document.querySelector('.errormessage');

        if (prev_error) {
            prev_error.remove();
        }

        document.querySelector('.passwordbutton').insertAdjacentHTML('afterend', `
        <p class='errormessage'>${text['html']}</p>
        `);
        }
}


document.querySelector('.passwordbutton').addEventListener('click', sendLoginData);